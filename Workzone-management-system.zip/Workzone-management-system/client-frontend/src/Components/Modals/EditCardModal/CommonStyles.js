import styled from 'styled-components';

export const CommonButton = styled.button``;
